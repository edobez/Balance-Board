﻿
namespace PIDLibrary
{
    public delegate double GetDouble();
    public delegate void SetDouble(double value);
}
